wget http://www.thespermwhale.com/jaseweston/babi/tasks_1-20_v1-2.tar.gz
tar xzvf ./tasks_1-20_v1-2.tar.gz
mkdir -P bAbI
mv tasks_1-20_v1-2 ./bAbI
