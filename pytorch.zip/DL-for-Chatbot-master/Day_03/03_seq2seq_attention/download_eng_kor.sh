mkdir data
wget http://www.manythings.org/anki/kor-eng.zip
unzip kor-eng.zip
mv kor.txt ./data/eng-kor.txt
