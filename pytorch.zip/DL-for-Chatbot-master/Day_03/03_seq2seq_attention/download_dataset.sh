mkdir data
wget http://www.manythings.org/anki/fra-eng.zip
unzip fra-eng.zip
mv fra.txt ./data/eng-fra.txt
